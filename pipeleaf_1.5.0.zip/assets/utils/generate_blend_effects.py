combos = [('catmint', 'orangemallow'), ('catmint', 'poisonoak'), ('catmint', 'goldenpoppy'), ('catmint', 'cornflower'), ('catmint', 'chamomile'), ('catmint', 'lavender'), ('catmint', 'marjoram'), ('catmint', 'marshmallow'), ('catmint', 'mint'), ('catmint', 'rosemary'), ('catmint', 'saffron'), ('catmint', 'sage'), ('catmint', 'stingingnettle'), ('catmint', 'stjohnswort'), ('catmint', 'thyme'), ('catmint', 'mugwort'), ('catmint', 'chicory'), ('catmint', 'marigold'), ('catmint', 'yarrow'), ('catmint', 'angelica'), ('catmint', 'arnica'), ('catmint', 'horehound'), ('catmint', 'ginseng'), ('orangemallow', 'catmint'), ('orangemallow', 'poisonoak'), ('orangemallow', 'goldenpoppy'), ('orangemallow', 'cornflower'), ('orangemallow', 'chamomile'), ('orangemallow', 'lavender'), ('orangemallow', 'marjoram'), ('orangemallow', 'marshmallow'), ('orangemallow', 'mint'), ('orangemallow', 'rosemary'), ('orangemallow', 'saffron'), ('orangemallow', 'sage'), ('orangemallow', 'stingingnettle'), ('orangemallow', 'stjohnswort'), ('orangemallow', 'thyme'), ('orangemallow', 'mugwort'), ('orangemallow', 'chicory'), ('orangemallow', 'marigold'), ('orangemallow', 'yarrow'), ('orangemallow', 'angelica'), ('orangemallow', 'arnica'), ('orangemallow', 'horehound'), ('orangemallow', 'ginseng'), ('poisonoak', 'catmint'), ('poisonoak', 'orangemallow'), ('poisonoak', 'goldenpoppy'), ('poisonoak', 'cornflower'), ('poisonoak', 'chamomile'), ('poisonoak', 'lavender'), ('poisonoak', 'marjoram'), ('poisonoak', 'marshmallow'), ('poisonoak', 'mint'), ('poisonoak', 'rosemary'), ('poisonoak', 'saffron'), ('poisonoak', 'sage'), ('poisonoak', 'stingingnettle'), ('poisonoak', 'stjohnswort'), ('poisonoak', 'thyme'), ('poisonoak', 'mugwort'), ('poisonoak', 'chicory'), ('poisonoak', 'marigold'), ('poisonoak', 'yarrow'), ('poisonoak', 'angelica'), ('poisonoak', 'arnica'), ('poisonoak', 'horehound'), ('poisonoak', 'ginseng'), ('goldenpoppy', 'catmint'), ('goldenpoppy', 'orangemallow'), ('goldenpoppy', 'poisonoak'), ('goldenpoppy', 'cornflower'), ('goldenpoppy', 'chamomile'), ('goldenpoppy', 'lavender'), ('goldenpoppy', 'marjoram'), ('goldenpoppy', 'marshmallow'), ('goldenpoppy', 'mint'), ('goldenpoppy', 'rosemary'), ('goldenpoppy', 'saffron'), ('goldenpoppy', 'sage'), ('goldenpoppy', 'stingingnettle'), ('goldenpoppy', 'stjohnswort'), ('goldenpoppy', 'thyme'), ('goldenpoppy', 'mugwort'), ('goldenpoppy', 'chicory'), ('goldenpoppy', 'marigold'), ('goldenpoppy', 'yarrow'), ('goldenpoppy', 'angelica'), ('goldenpoppy', 'arnica'), ('goldenpoppy', 'horehound'), ('goldenpoppy', 'ginseng'), ('cornflower', 'catmint'), ('cornflower', 'orangemallow'), ('cornflower', 'poisonoak'), ('cornflower', 'goldenpoppy'), ('cornflower', 'chamomile'), ('cornflower', 'lavender'), ('cornflower', 'marjoram'), ('cornflower', 'marshmallow'), ('cornflower', 'mint'), ('cornflower', 'rosemary'), ('cornflower', 'saffron'), ('cornflower', 'sage'), ('cornflower', 'stingingnettle'), ('cornflower', 'stjohnswort'), ('cornflower', 'thyme'), ('cornflower', 'mugwort'), ('cornflower', 'chicory'), ('cornflower', 'marigold'), ('cornflower', 'yarrow'), ('cornflower', 'angelica'), ('cornflower', 'arnica'), ('cornflower', 'horehound'), ('cornflower', 'ginseng'), ('chamomile', 'catmint'), ('chamomile', 'orangemallow'), ('chamomile', 'poisonoak'), ('chamomile', 'goldenpoppy'), ('chamomile', 'cornflower'), ('chamomile', 'lavender'), ('chamomile', 'marjoram'), ('chamomile', 'marshmallow'), ('chamomile', 'mint'), ('chamomile', 'rosemary'), ('chamomile', 'saffron'), ('chamomile', 'sage'), ('chamomile', 'stingingnettle'), ('chamomile', 'stjohnswort'), ('chamomile', 'thyme'), ('chamomile', 'mugwort'), ('chamomile', 'chicory'), ('chamomile', 'marigold'), ('chamomile', 'yarrow'), ('chamomile', 'angelica'), ('chamomile', 'arnica'), ('chamomile', 'horehound'), ('chamomile', 'ginseng'), ('lavender', 'catmint'), ('lavender', 'orangemallow'), ('lavender', 'poisonoak'), ('lavender', 'goldenpoppy'), ('lavender', 'cornflower'), ('lavender', 'chamomile'), ('lavender', 'marjoram'), ('lavender', 'marshmallow'), ('lavender', 'mint'), ('lavender', 'rosemary'), ('lavender', 'saffron'), ('lavender', 'sage'), ('lavender', 'stingingnettle'), ('lavender', 'stjohnswort'), ('lavender', 'thyme'), ('lavender', 'mugwort'), ('lavender', 'chicory'), ('lavender', 'marigold'), ('lavender', 'yarrow'), ('lavender', 'angelica'), ('lavender', 'arnica'), ('lavender', 'horehound'), ('lavender', 'ginseng'), ('marjoram', 'catmint'), ('marjoram', 'orangemallow'), ('marjoram', 'poisonoak'), ('marjoram', 'goldenpoppy'), ('marjoram', 'cornflower'), ('marjoram', 'chamomile'), ('marjoram', 'lavender'), ('marjoram', 'marshmallow'), ('marjoram', 'mint'), ('marjoram', 'rosemary'), ('marjoram', 'saffron'), ('marjoram', 'sage'), ('marjoram', 'stingingnettle'), ('marjoram', 'stjohnswort'), ('marjoram', 'thyme'), ('marjoram', 'mugwort'), ('marjoram', 'chicory'), ('marjoram', 'marigold'), ('marjoram', 'yarrow'), ('marjoram', 'angelica'), ('marjoram', 'arnica'), ('marjoram', 'horehound'), ('marjoram', 'ginseng'), ('marshmallow', 'catmint'), ('marshmallow', 'orangemallow'), ('marshmallow', 'poisonoak'), ('marshmallow', 'goldenpoppy'), ('marshmallow', 'cornflower'), ('marshmallow', 'chamomile'), ('marshmallow', 'lavender'), ('marshmallow', 'marjoram'), ('marshmallow', 'mint'), ('marshmallow', 'rosemary'), ('marshmallow', 'saffron'), ('marshmallow', 'sage'), ('marshmallow', 'stingingnettle'), ('marshmallow', 'stjohnswort'), ('marshmallow', 'thyme'), ('marshmallow', 'mugwort'), ('marshmallow', 'chicory'), ('marshmallow', 'marigold'), ('marshmallow', 'yarrow'), ('marshmallow', 'angelica'), ('marshmallow', 'arnica'), ('marshmallow', 'horehound'), ('marshmallow', 'ginseng'), ('mint', 'catmint'), ('mint', 'orangemallow'), ('mint', 'poisonoak'), ('mint', 'goldenpoppy'), ('mint', 'cornflower'), ('mint', 'chamomile'), ('mint', 'lavender'), ('mint', 'marjoram'), ('mint', 'marshmallow'), ('mint', 'rosemary'), ('mint', 'saffron'), ('mint', 'sage'), ('mint', 'stingingnettle'), ('mint', 'stjohnswort'), ('mint', 'thyme'), ('mint', 'mugwort'), ('mint', 'chicory'), ('mint', 'marigold'), ('mint', 'yarrow'), ('mint', 'angelica'), ('mint', 'arnica'), ('mint', 'horehound'), ('mint', 'ginseng'), ('rosemary', 'catmint'), ('rosemary', 'orangemallow'), ('rosemary', 'poisonoak'), ('rosemary', 'goldenpoppy'), ('rosemary', 'cornflower'), ('rosemary', 'chamomile'), ('rosemary', 'lavender'), ('rosemary', 'marjoram'), ('rosemary', 'marshmallow'), ('rosemary', 'mint'), ('rosemary', 'saffron'), ('rosemary', 'sage'), ('rosemary', 'stingingnettle'), ('rosemary', 'stjohnswort'), ('rosemary', 'thyme'), ('rosemary', 'mugwort'), ('rosemary', 'chicory'), ('rosemary', 'marigold'), ('rosemary', 'yarrow'), ('rosemary', 'angelica'), ('rosemary', 'arnica'), ('rosemary', 'horehound'), ('rosemary', 'ginseng'), ('saffron', 'catmint'), ('saffron', 'orangemallow'), ('saffron', 'poisonoak'), ('saffron', 'goldenpoppy'), ('saffron', 'cornflower'), ('saffron', 'chamomile'), ('saffron', 'lavender'), ('saffron', 'marjoram'), ('saffron', 'marshmallow'), ('saffron', 'mint'), ('saffron', 'rosemary'), ('saffron', 'sage'), ('saffron', 'stingingnettle'), ('saffron', 'stjohnswort'), ('saffron', 'thyme'), ('saffron', 'mugwort'), ('saffron', 'chicory'), ('saffron', 'marigold'), ('saffron', 'yarrow'), ('saffron', 'angelica'), ('saffron', 'arnica'), ('saffron', 'horehound'), ('saffron', 'ginseng'), ('sage', 'catmint'), ('sage', 'orangemallow'), ('sage', 'poisonoak'), ('sage', 'goldenpoppy'), ('sage', 'cornflower'), ('sage', 'chamomile'), ('sage', 'lavender'), ('sage', 'marjoram'), ('sage', 'marshmallow'), ('sage', 'mint'), ('sage', 'rosemary'), ('sage', 'saffron'), ('sage', 'stingingnettle'), ('sage', 'stjohnswort'), ('sage', 'thyme'), ('sage', 'mugwort'), ('sage', 'chicory'), ('sage', 'marigold'), ('sage', 'yarrow'), ('sage', 'angelica'), ('sage', 'arnica'), ('sage', 'horehound'), ('sage', 'ginseng'), ('stingingnettle', 'catmint'), ('stingingnettle', 'orangemallow'), ('stingingnettle', 'poisonoak'), ('stingingnettle', 'goldenpoppy'), ('stingingnettle', 'cornflower'), ('stingingnettle', 'chamomile'), ('stingingnettle', 'lavender'), ('stingingnettle', 'marjoram'), ('stingingnettle', 'marshmallow'), ('stingingnettle', 'mint'), ('stingingnettle', 'rosemary'), ('stingingnettle', 'saffron'), ('stingingnettle', 'sage'), ('stingingnettle', 'stjohnswort'), ('stingingnettle', 'thyme'), ('stingingnettle', 'mugwort'), ('stingingnettle', 'chicory'), ('stingingnettle', 'marigold'), ('stingingnettle', 'yarrow'), ('stingingnettle', 'angelica'), ('stingingnettle', 'arnica'), ('stingingnettle', 'horehound'), ('stingingnettle', 'ginseng'), ('stjohnswort', 'catmint'), ('stjohnswort', 'orangemallow'), ('stjohnswort', 'poisonoak'), ('stjohnswort', 'goldenpoppy'), ('stjohnswort', 'cornflower'), ('stjohnswort', 'chamomile'), ('stjohnswort', 'lavender'), ('stjohnswort', 'marjoram'), ('stjohnswort', 'marshmallow'), ('stjohnswort', 'mint'), ('stjohnswort', 'rosemary'), ('stjohnswort', 'saffron'), ('stjohnswort', 'sage'), ('stjohnswort', 'stingingnettle'), ('stjohnswort', 'thyme'), ('stjohnswort', 'mugwort'), ('stjohnswort', 'chicory'), ('stjohnswort', 'marigold'), ('stjohnswort', 'yarrow'), ('stjohnswort', 'angelica'), ('stjohnswort', 'arnica'), ('stjohnswort', 'horehound'), ('stjohnswort', 'ginseng'), ('thyme', 'catmint'), ('thyme', 'orangemallow'), ('thyme', 'poisonoak'), ('thyme', 'goldenpoppy'), ('thyme', 'cornflower'), ('thyme', 'chamomile'), ('thyme', 'lavender'), ('thyme', 'marjoram'), ('thyme', 'marshmallow'), ('thyme', 'mint'), ('thyme', 'rosemary'), ('thyme', 'saffron'), ('thyme', 'sage'), ('thyme', 'stingingnettle'), ('thyme', 'stjohnswort'), ('thyme', 'mugwort'), ('thyme', 'chicory'), ('thyme', 'marigold'), ('thyme', 'yarrow'), ('thyme', 'angelica'), ('thyme', 'arnica'), ('thyme', 'horehound'), ('thyme', 'ginseng'), ('mugwort', 'catmint'), ('mugwort', 'orangemallow'), ('mugwort', 'poisonoak'), ('mugwort', 'goldenpoppy'), ('mugwort', 'cornflower'), ('mugwort', 'chamomile'), ('mugwort', 'lavender'), ('mugwort', 'marjoram'), ('mugwort', 'marshmallow'), ('mugwort', 'mint'), ('mugwort', 'rosemary'), ('mugwort', 'saffron'), ('mugwort', 'sage'), ('mugwort', 'stingingnettle'), ('mugwort', 'stjohnswort'), ('mugwort', 'thyme'), ('mugwort', 'chicory'), ('mugwort', 'marigold'), ('mugwort', 'yarrow'), ('mugwort', 'angelica'), ('mugwort', 'arnica'), ('mugwort', 'horehound'), ('mugwort', 'ginseng'), ('chicory', 'catmint'), ('chicory', 'orangemallow'), ('chicory', 'poisonoak'), ('chicory', 'goldenpoppy'), ('chicory', 'cornflower'), ('chicory', 'chamomile'), ('chicory', 'lavender'), ('chicory', 'marjoram'), ('chicory', 'marshmallow'), ('chicory', 'mint'), ('chicory', 'rosemary'), ('chicory', 'saffron'), ('chicory', 'sage'), ('chicory', 'stingingnettle'), ('chicory', 'stjohnswort'), ('chicory', 'thyme'), ('chicory', 'mugwort'), ('chicory', 'marigold'), ('chicory', 'yarrow'), ('chicory', 'angelica'), ('chicory', 'arnica'), ('chicory', 'horehound'), ('chicory', 'ginseng'), ('marigold', 'catmint'), ('marigold', 'orangemallow'), ('marigold', 'poisonoak'), ('marigold', 'goldenpoppy'), ('marigold', 'cornflower'), ('marigold', 'chamomile'), ('marigold', 'lavender'), ('marigold', 'marjoram'), ('marigold', 'marshmallow'), ('marigold', 'mint'), ('marigold', 'rosemary'), ('marigold', 'saffron'), ('marigold', 'sage'), ('marigold', 'stingingnettle'), ('marigold', 'stjohnswort'), ('marigold', 'thyme'), ('marigold', 'mugwort'), ('marigold', 'chicory'), ('marigold', 'yarrow'), ('marigold', 'angelica'), ('marigold', 'arnica'), ('marigold', 'horehound'), ('marigold', 'ginseng'), ('yarrow', 'catmint'), ('yarrow', 'orangemallow'), ('yarrow', 'poisonoak'), ('yarrow', 'goldenpoppy'), ('yarrow', 'cornflower'), ('yarrow', 'chamomile'), ('yarrow', 'lavender'), ('yarrow', 'marjoram'), ('yarrow', 'marshmallow'), ('yarrow', 'mint'), ('yarrow', 'rosemary'), ('yarrow', 'saffron'), ('yarrow', 'sage'), ('yarrow', 'stingingnettle'), ('yarrow', 'stjohnswort'), ('yarrow', 'thyme'), ('yarrow', 'mugwort'), ('yarrow', 'chicory'), ('yarrow', 'marigold'), ('yarrow', 'angelica'), ('yarrow', 'arnica'), ('yarrow', 'horehound'), ('yarrow', 'ginseng'), ('angelica', 'catmint'), ('angelica', 'orangemallow'), ('angelica', 'poisonoak'), ('angelica', 'goldenpoppy'), ('angelica', 'cornflower'), ('angelica', 'chamomile'), ('angelica', 'lavender'), ('angelica', 'marjoram'), ('angelica', 'marshmallow'), ('angelica', 'mint'), ('angelica', 'rosemary'), ('angelica', 'saffron'), ('angelica', 'sage'), ('angelica', 'stingingnettle'), ('angelica', 'stjohnswort'), ('angelica', 'thyme'), ('angelica', 'mugwort'), ('angelica', 'chicory'), ('angelica', 'marigold'), ('angelica', 'yarrow'), ('angelica', 'arnica'), ('angelica', 'horehound'), ('angelica', 'ginseng'), ('arnica', 'catmint'), ('arnica', 'orangemallow'), ('arnica', 'poisonoak'), ('arnica', 'goldenpoppy'), ('arnica', 'cornflower'), ('arnica', 'chamomile'), ('arnica', 'lavender'), ('arnica', 'marjoram'), ('arnica', 'marshmallow'), ('arnica', 'mint'), ('arnica', 'rosemary'), ('arnica', 'saffron'), ('arnica', 'sage'), ('arnica', 'stingingnettle'), ('arnica', 'stjohnswort'), ('arnica', 'thyme'), ('arnica', 'mugwort'), ('arnica', 'chicory'), ('arnica', 'marigold'), ('arnica', 'yarrow'), ('arnica', 'angelica'), ('arnica', 'horehound'), ('arnica', 'ginseng'), ('horehound', 'catmint'), ('horehound', 'orangemallow'), ('horehound', 'poisonoak'), ('horehound', 'goldenpoppy'), ('horehound', 'cornflower'), ('horehound', 'chamomile'), ('horehound', 'lavender'), ('horehound', 'marjoram'), ('horehound', 'marshmallow'), ('horehound', 'mint'), ('horehound', 'rosemary'), ('horehound', 'saffron'), ('horehound', 'sage'), ('horehound', 'stingingnettle'), ('horehound', 'stjohnswort'), ('horehound', 'thyme'), ('horehound', 'mugwort'), ('horehound', 'chicory'), ('horehound', 'marigold'), ('horehound', 'yarrow'), ('horehound', 'angelica'), ('horehound', 'arnica'), ('horehound', 'ginseng'), ('ginseng', 'catmint'), ('ginseng', 'orangemallow'), ('ginseng', 'poisonoak'), ('ginseng', 'goldenpoppy'), ('ginseng', 'cornflower'), ('ginseng', 'chamomile'), ('ginseng', 'lavender'), ('ginseng', 'marjoram'), ('ginseng', 'marshmallow'), ('ginseng', 'mint'), ('ginseng', 'rosemary'), ('ginseng', 'saffron'), ('ginseng', 'sage'), ('ginseng', 'stingingnettle'), ('ginseng', 'stjohnswort'), ('ginseng', 'thyme'), ('ginseng', 'mugwort'), ('ginseng', 'chicory'), ('ginseng', 'marigold'), ('ginseng', 'yarrow'), ('ginseng', 'angelica'), ('ginseng', 'arnica'), ('ginseng', 'horehound')]

shagfx = {
    "smokable-catmint-shag": {
      "smokableEffects": [
        {
          "type": "temporalstability",
          "amount": -0.25,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Catmint may cause temporary insanity."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-goldenpoppy-shag": {
      "smokableEffects": [
        {
          "type": "tiredness",
          "amount": 5,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Golden Poppy will boost temporal stability and makes you sleepy."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-cornflower-shag": {
      "smokableEffects": [
        {
          "type": "bodytemperature",
          "amount": 4,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Cornflower Shag will make you feel warmer in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-orangemallow-shag": {
      "smokableEffects": [
        {
          "type": "intoxication",
          "amount": 0.15,
          "cooldown": 0
        },
        {
          "type": "hungerrate",
          "amount": -0.15,
          "cooldown": 900 # 15 minutes
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Orange Mallow has a mild intoxicating effect and makes you less hungry."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-sage-shag": {
      "smokableEffects": [
        {
          "type": "temporalstability", # watchedAttribute, not a Stat 
          "amount": 0.15,
          "cooldown": 0 # natural environment wears down the buff so no need to remove buff manually
        },
        {
          "type": "intoxication",
          "amount": 0.5,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Sage has a heavy intoxicating effect, will boost temporal stability, and warms you in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-mugwort-shag": {
      "smokableEffects": [
        {
          "type": "intoxication",
          "amount": 0.15,
          "cooldown": 0
        },
        {
          "type": "bodytemperature", # behavior based, not a stat
          "amount": 4,
          "cooldown": 0 # body temp maxes out and reduces naturally
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Mugwort has mild intoxicating effects and warms you in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-marshmallow-shag": {
      "smokableEffects": [
        {
          "type": "intoxication",
          "amount": 0.15,
          "cooldown": 0
        },
        {
          "type": "bodytemperature", # behavior based, not a stat
          "amount": 4,
          "cooldown": 0 # body temp maxes out and reduces naturally
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Marshmallow has mild intoxicating effects and warms you in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-chamomile-shag": {
      "smokableEffects": [
        {
          "type": "tiredness",
          "amount": 4,
          "cooldown": 0
        },
        {
          "type": "bodytemperature", # behavior based, not a stat
          "amount": 4,
          "cooldown": 0 # body temp maxes out and reduces naturally
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Chamomile makes you sleepy and warms you in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-marjoram-shag": {
      "smokableEffects": [
        {
          "type": "hungerrate",
          "amount": -0.15,
          "cooldown": 900 # 15 minutes
        },
        {
          "type": "tiredness",
          "amount": 4,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Majorum makes you sleepy and less hungry."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-lavender-shag": {
      "smokableEffects": [
        {
          "type": "tiredness",
          "amount": 4,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Lavendar makes you sleepy."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-saffron-shag": {
      "smokableEffects": [
        {
          "type": "intoxication",
          "amount": 0.2,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Saffron has mild intoxicating effects and warm you in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-thyme-shag": {
      "smokableEffects": [
        {
          "type": "temporalstability", # watchedAttribute, not a Stat 
          "amount": 0.15,
          "cooldown": 0 # natural environment wears down the buff so no need to remove buff manually
        },
        {
          "type": "bodytemperature", # behavior based, not a stat
          "amount": 4,
          "cooldown": 0 # body temp maxes out and reduces naturally
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Thyme will boost temporal stability, and warms you in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-poisonoak-shag": {
      "smokableEffects": [
        {
          "type": "healthpoints",
          "amount": "-5",
          "cooldown": 0
        },
        {
          "type": "temporalstability", # watchedAttribute, not a Stat 
          "amount": -0.60,
          "cooldown": 0 # natural environment wears down the buff so no need to remove buff manually
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking Poison Oak sounds like a bad idea."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    },
    "smokable-*-shag": {
      "smokableEffects": [
        {
          "type": "bodytemperature",
          "amount": 4,
          "cooldown": 0
        }
      ],
      "handbook": {
        "groupBy": [ "smokable-*-shag" ],
        "extraSections": [
          {
            "title": "pipeleaf:handbook-item-effect",
            "text": "Smoking this will warm you in the cold."
          }
        ]
      },
      "inFirePitProps": {
        "transform": {
          "scale": 0.37,
          "origin": {
            "x": 0.5,
            "y": 0.0625,
            "z": 0.5
          },
          "translation": {
            "x": 0.03125,
            "y": 0,
            "z": 0
          },
          "rotation": {
            "x": 0,
            "y": 45,
            "z": 0
          }
        },
        "useFirepitModel": "Spit"
      }
    }
}

shagfx = {k.split('-')[1]: v['smokableEffects'] for k, v in shagfx.items()}

blendfx = {}

defaultfx = [{
          "type": "bodytemperature",
          "amount": 4,
          "cooldown": 0
        }]


for ing1, ing2 in combos:
    fx1 = shagfx.get(ing1, defaultfx)
    fx2 = shagfx.get(ing2, defaultfx)

    fxs = fx1 + [fx2[0]]

    fxs_dedupe = {f['type']: f for f in fxs}

    blendfx[f'shagblend-{ing1}-{ing2}'] = {
        'smokableEffects': list(fxs_dedupe.values()),
        'handbook': {"exclude": True}
    }

import json
print(json.dumps(blendfx))